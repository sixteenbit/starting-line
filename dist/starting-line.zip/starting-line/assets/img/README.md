# Images source

Drop the source of image (jpg, png, gif, svg) files in this directory and grunt will optimize and copy to `assets/img`.
